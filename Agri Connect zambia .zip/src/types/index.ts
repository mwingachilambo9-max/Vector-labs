export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  quantity: number;
  location: string;
  farmerName: string;
  farmerPhone: string;
  image: string;
  description: string;
  datePosted: string;
}

export interface LearningResource {
  id: string;
  title: string;
  category: string;
  description: string;
  duration: string;
  image: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface User {
  id: string;
  name: string;
  role: 'farmer' | 'buyer';
  phone: string;
  location: string;
}
