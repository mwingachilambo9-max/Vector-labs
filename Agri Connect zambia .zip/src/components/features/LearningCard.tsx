import { LearningResource } from '@/types';
import { Clock, BookOpen } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface LearningCardProps {
  resource: LearningResource;
}

export function LearningCard({ resource }: LearningCardProps) {
  const difficultyColors = {
    Beginner: 'bg-green-100 text-green-800 border-green-200',
    Intermediate: 'bg-blue-100 text-blue-800 border-blue-200',
    Advanced: 'bg-orange-100 text-orange-800 border-orange-200',
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
      <div className="aspect-video overflow-hidden">
        <img
          src={resource.image}
          alt={resource.title}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <Badge variant="outline" className="text-xs">
            {resource.category}
          </Badge>
          <Badge
            variant="outline"
            className={`text-xs ${difficultyColors[resource.difficulty]}`}
          >
            {resource.difficulty}
          </Badge>
        </div>
        
        <h3 className="font-semibold text-lg mb-2">{resource.title}</h3>
        
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
          {resource.description}
        </p>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{resource.duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <BookOpen className="h-4 w-4" />
            <span>Learn</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
