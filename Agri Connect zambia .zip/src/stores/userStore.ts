import { create } from 'zustand';
import { User } from '@/types';

interface UserState {
  user: User | null;
  setUser: (user: User | null) => void;
  toggleRole: () => void;
}

// Mock user for demo purposes
const MOCK_FARMER: User = {
  id: '1',
  name: 'John Mwale',
  role: 'farmer',
  phone: '+260 97 123 4567',
  location: 'Lusaka',
};

const MOCK_BUYER: User = {
  id: '2',
  name: 'Sarah Tembo',
  role: 'buyer',
  phone: '+260 96 987 6543',
  location: 'Ndola',
};

export const useUserStore = create<UserState>((set) => ({
  user: MOCK_FARMER,
  setUser: (user) => set({ user }),
  toggleRole: () =>
    set((state) => ({
      user: state.user?.role === 'farmer' ? MOCK_BUYER : MOCK_FARMER,
    })),
}));
