import { create } from 'zustand';
import { Product } from '@/types';
import { MOCK_PRODUCTS } from '@/constants/mockData';

interface ProductState {
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'datePosted'>) => void;
}

export const useProductStore = create<ProductState>((set) => ({
  products: MOCK_PRODUCTS,
  addProduct: (product) =>
    set((state) => ({
      products: [
        {
          ...product,
          id: `${Date.now()}`,
          datePosted: new Date().toISOString().split('T')[0],
        },
        ...state.products,
      ],
    })),
}));
