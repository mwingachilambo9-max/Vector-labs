import { useParams, Link } from 'react-router-dom';
import { useProductStore } from '@/stores/productStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Phone, Calendar, Package, ArrowLeft } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export function ProductDetail() {
  const { id } = useParams();
  const { products } = useProductStore();
  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Product not found</h2>
          <Link to="/marketplace">
            <Button>Back to Marketplace</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="container mx-auto px-4">
        <Link to="/marketplace">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Marketplace
          </Button>
        </Link>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Image */}
          <div className="aspect-square overflow-hidden rounded-lg">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Details */}
          <div>
            <Badge className="mb-3">{product.category}</Badge>
            <h1 className="text-4xl font-bold mb-4">{product.name}</h1>
            
            <div className="flex items-baseline gap-2 mb-6">
              <span className="text-4xl font-bold text-primary">
                K{product.price}
              </span>
              <span className="text-xl text-muted-foreground">
                per {product.unit}
              </span>
            </div>

            <Card className="mb-6">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <Package className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Available Quantity</p>
                    <p className="font-semibold">
                      {product.quantity} {product.unit}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="font-semibold">{product.location}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Posted</p>
                    <p className="font-semibold">
                      {new Date(product.datePosted).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-3">Description</h2>
              <p className="text-muted-foreground leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Farmer Contact */}
            <Card className="bg-primary/5">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Contact Farmer</h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground">Farmer Name</p>
                    <p className="font-medium">{product.farmerName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Phone Number</p>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      <p className="font-medium">{product.farmerPhone}</p>
                    </div>
                  </div>
                  <Button className="w-full mt-4">
                    <Phone className="mr-2 h-4 w-4" />
                    Call Farmer
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
